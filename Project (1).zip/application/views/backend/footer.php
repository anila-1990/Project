 <!-- footer content -->

        <footer>

         

          <div class="clearfix"></div>

        </footer>

        <!-- /footer content -->

      </div>

    </div>



    <!-- jQuery -->
 <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- FastClick -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/fastclick/lib/fastclick.js"></script>

    <!-- NProgress -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/nprogress/nprogress.js"></script>

    <!-- Chart.js -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Chart.js/dist/Chart.min.js"></script>

    <!-- gauge.js -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/gauge.js/dist/gauge.min.js"></script>

    <!-- bootstrap-progressbar -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>

    <!-- iCheck -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/iCheck/icheck.min.js"></script>

    <!-- Skycons -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/skycons/skycons.js"></script>

    <!-- Flot -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Flot/jquery.flot.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Flot/jquery.flot.pie.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Flot/jquery.flot.time.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Flot/jquery.flot.stack.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/Flot/jquery.flot.resize.js"></script>

    <!-- Flot plugins -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/flot-spline/js/jquery.flot.spline.min.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/flot.curvedlines/curvedLines.js"></script>

    <!-- DateJS -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/DateJS/build/date.js"></script>

    <!-- JQVMap -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/jqvmap/dist/jquery.vmap.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>

    <!-- bootstrap-daterangepicker -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/moment/min/moment.min.js"></script>

    <script src="<?php echo base_url().'template/backend/theme/'; ?>vendors/bootstrap-daterangepicker/daterangepicker.js"></script>



    <!-- Custom Theme Scripts -->

    <script src="<?php echo base_url().'template/backend/theme/'; ?>build/js/custom.min.js"></script>

	

  </body>

</html>