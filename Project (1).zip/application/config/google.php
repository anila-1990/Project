<?php defined('BASEPATH') OR exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
|  client_id         string   Your Google API Client ID.
|  client_secret     string   Your Google API Client secret.
|  redirect_uri      string   URL to redirect back to after login.
|  application_name  string   Your Google application name.
|  api_key           string   Developer key.
|  scopes            string   Specify scopes
*/
$config['google']['client_id']        = '430858818871-utvcirvap5r7svg2cc8ns44cisb1adcs.apps.googleusercontent.com';
$config['google']['client_secret']    = 'jTqKHWCCfbAZixua7dRvoRlA';
$config['google']['redirect_uri']     = 'http://aksharakishor.com/akshara.com/user_authentication/googlelogin';
$config['google']['application_name'] = 'Akshara';
$config['google']['api_key']          = 'AIzaSyBdvVHpDDXPT_FnJU5ZRQ3OZL_W1FL3Ad4';
$config['google']['scopes']           = array();
?>
